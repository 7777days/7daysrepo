# -*- coding: utf-8 -*-
__author__ = "NightRain"


import os
import sys
import xbmcaddon, xbmcvfs
import urllib

__cwd__ = xbmcvfs.translatePath( xbmcaddon.Addon().getAddonInfo('path') )
__lib__ = os.path.join( __cwd__, 'resources', 'lib' )
sys.path.append(__lib__)

from coupangRun import *

### get_parms start ###
def get_params():
	p = urllib.parse.parse_qs(sys.argv[2][1:])
	for i in p.keys():
		p[i] = p[i][0]
	return p
### get_parms end ###


runObj = CoupangRun( sys.argv[0], int(sys.argv[1]), get_params() )  ### main class 생성
runObj.coupang_main()


### main process end ####

